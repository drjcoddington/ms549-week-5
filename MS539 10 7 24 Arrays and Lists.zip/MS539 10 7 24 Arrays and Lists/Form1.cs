﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MS539_10_7_24_Arrays_and_Lists
{
    public partial class Form1 : Form
    {
        String[] texts = new string[5];
        int[] nums = new int[3];

        List<int> listNums = new List<int>();   
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string longString = string.Empty;
            texts[0] = textBox1.Text;
            texts[1] = textBox2.Text;
            texts[2] = textBox3.Text;
            texts[3] = "happy Holloweeen";
            texts[4] = "Ms539";

            for (int i = 0;i < texts.Length;i++)
            {
                longString += texts[i];// longString = longString + texts[i]
            }

            textBox7.Text = longString;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            double sum = 0;
            if (int.TryParse(textBox4.Text, out nums[0]) && int.TryParse(textBox5.Text, out nums[1]) && int.TryParse(textBox6.Text, out nums[2]))
            {
                for (int i = 0;i<nums.Length;i++) 
                { 
                    sum += nums[i];
                }
                textBox7.Text = sum.ToString();

            }
            MessageBox.Show("sum of arrays using a function" + nums.Sum());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox4.Text, out nums[0]) && int.TryParse(textBox5.Text, out nums[1]) && int.TryParse(textBox6.Text, out nums[2]))
            {
                Array.Sort(nums);
                textBox4.Text = nums[0].ToString();
                textBox5.Text = nums[1].ToString();
                textBox6.Text = nums[2].ToString();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
          if ( int.TryParse(textBox4.Text, out nums[0]) && int.TryParse(textBox5.Text, out nums[1]) && int.TryParse(textBox6.Text, out nums[2]))
            {
                listNums.Add(nums[0]);
                listNums.Add(nums[1]);
                listNums.Add(nums[2]);

                listNums.Sort();
                textBox4.Text = listNums[0].ToString();
                textBox5.Text = listNums[1].ToString();
                textBox6.Text = listNums[2].ToString();

                int sum = listNums.Sum();

                textBox7.Text = sum.ToString();

            }
        }
    }
}
